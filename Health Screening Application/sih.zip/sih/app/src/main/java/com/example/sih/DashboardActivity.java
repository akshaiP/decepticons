package com.example.sih;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sih.R;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.squareup.picasso.Picasso;

public class DashboardActivity extends AppCompatActivity {

    private ImageView Profile;

    private ImageView Voicecall;

    private ImageView question;
    private TextView Name;
    GoogleSignInOptions gso;
    private FirebaseFirestore fstore;
    private FirebaseAuth mAuth;

    String UserId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Profile=findViewById(R.id.imageView4);
        Name=findViewById(R.id.textView3);
        question=findViewById(R.id.ques);
        Voicecall=findViewById(R.id.voicecall);

        fstore= FirebaseFirestore.getInstance();
        mAuth= FirebaseAuth.getInstance();

        UserId=mAuth.getCurrentUser().getUid();

        DocumentReference documentReference=fstore.collection("users").document(UserId);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    // Handle any errors here
                    return;
                }

                if (value != null && value.exists()) {
                    // Data from Firestore exists for the user// Assuming "email" is the field name in Firestore
                    String userName = value.getString("Name"); // Assuming "name" is the field name in Firestore

                    // Set the email and name fields in your UI

                    Name.setText(userName);
                }
            }
        });


        gso = new  GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();


        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if(acct!=null){
            String personename=acct.getDisplayName();
            String email=acct.getEmail();
            Name.setText(personename);

            Uri personPhoto = acct.getPhotoUrl();
            if (personPhoto != null) {
                String photoUrl = personPhoto.toString();
                Picasso.get().load(photoUrl).into(Profile);
            }
        }
        Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DashboardActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });
        question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1=new Intent(DashboardActivity.this,QuestionaireActivity.class);
                startActivity(intent1);
            }
        });
        Voicecall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:+1860-317-6113"));
                startActivity(intent);
            }
        });

    }
}