package com.example.sih;

public interface mycompletelistner {
    void onSuccess();
    void onFailure();
}
